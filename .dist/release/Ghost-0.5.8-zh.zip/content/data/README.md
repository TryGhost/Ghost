# Content / Data

If using the standard file storage, Ghost will save default db here.