* [9f93485](https://github.com/TryGhost/Casper/commit/9f93485) v5.6.0 - Steve Larson
* [840b1b9](https://github.com/TryGhost/Casper/commit/840b1b9) Switched from padding to margin for page card spacing - Sodbileg Gansukh
* [cc3fca0](https://github.com/TryGhost/Casper/commit/cc3fca0) Fixed cards not having space below - Sodbileg Gansukh
* [f8b34f9](https://github.com/TryGhost/Casper/commit/f8b34f9) Fixed article header spacing on post template - Sodbileg Gansukh
* [b9f5d59](https://github.com/TryGhost/Casper/commit/b9f5d59) Rebuilt assets - Sodbileg Gansukh
* [a60e3e9](https://github.com/TryGhost/Casper/commit/a60e3e9) Updated hiding page title and feature image implementation (#946) - Sanne de Vries
* [d9c9390](https://github.com/TryGhost/Casper/commit/d9c9390) Removed padding between navigation and full width content (#944) - Sanne de Vries
* [84f201d](https://github.com/TryGhost/Casper/commit/84f201d) Updated class to 'kg-card-hascaption' - Sanne de Vries
* [c7fdfb7](https://github.com/TryGhost/Casper/commit/c7fdfb7) Removed spacing between full-width cards - Sanne de Vries
* [d348349](https://github.com/TryGhost/Casper/commit/d348349) Added support for hidden title and feature image on pages (#943) - Sanne de Vries
