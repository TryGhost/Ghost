* [e29691b](https://github.com/TryGhost/Casper/commit/e29691b) v5.8.0 - Sodbileg Gansukh
* [d9942b8](https://github.com/TryGhost/Casper/commit/d9942b8) Rebuilt assets - Sodbileg Gansukh
* [6c4397a](https://github.com/TryGhost/Casper/commit/6c4397a) Added custom fonts support (#986) - Sodbileg Gansukh
* [cdaa6b3](https://github.com/TryGhost/Casper/commit/cdaa6b3) Improved multi-author support - Sodbileg Gansukh
