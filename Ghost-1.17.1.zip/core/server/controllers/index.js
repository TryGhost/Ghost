module.exports = {
    preview: require('./preview'),
    entry: require('./entry')
};
