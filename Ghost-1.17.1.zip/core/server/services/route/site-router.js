// Site Router is the top level Router for the whole site
var ParentRouter = require('./ParentRouter'),
    siteRouter = new ParentRouter('site');

module.exports = siteRouter;
