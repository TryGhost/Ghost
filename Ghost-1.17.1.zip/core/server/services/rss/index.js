module.exports = require('./cache');
