var cards = require('./cards'),
    atoms = require('./atoms');
module.exports = {
    cards: cards,
    atoms: atoms,
    activate: function () {
        // needed by ghost
    }
};
