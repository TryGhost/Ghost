var hr = require('./hr'),
    html = require('./html'),
    image = require('./image'),
    markdown = require('./markdown');

module.exports = [hr, html, image, markdown];
