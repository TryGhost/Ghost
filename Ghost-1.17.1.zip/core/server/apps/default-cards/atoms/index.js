var softReturn = require('./soft-return');

module.exports = [softReturn];
